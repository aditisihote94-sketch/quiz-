const quiz = [
  {
    question: "Indian Constitution came into force on?",
    options: ["15 August 1947", "26 January 1950", "2 October 1950"],
    answer: "26 January 1950"
  },
  {
    question: "Father of Indian Constitution?",
    options: ["Jawaharlal Nehru", "Dr. B. R. Ambedkar", "Mahatma Gandhi"],
    answer: "Dr. B. R. Ambedkar"
  },
  {
    question: "Highest court in India?",
    options: ["High Court", "Supreme Court", "District Court"],
    answer: "Supreme Court"
  },
  {
    question: "Article for Right to Equality?",
    options: ["Article 14", "Article 19", "Article 21"],
    answer: "Article 14"
  },
  {
    question: "IPC stands for?",
    options: ["Indian Penal Code", "Indian Police Code", "Indian Procedure Code"],
    answer: "Indian Penal Code"
  }
];

let current = 0;
let score = 0;
let musicStarted = false;

/* 🎵 background music start */
function startMusic() {
  if (!musicStarted) {
    const music = document.getElementById("bg-music");
    music.volume = 0.4;
    music.play();
    musicStarted = true;
  }
}

function loadQuestion() {
  const q = quiz[current];
  document.getElementById("question").innerText = q.question;

  const optionsDiv = document.getElementById("options");
  const feedback = document.getElementById("feedback");

  optionsDiv.innerHTML = "";
  feedback.innerText = "";

  q.options.forEach(opt => {
    const btn = document.createElement("button");
    btn.className = "btn btn-outline-secondary w-100 option-btn";
    btn.innerText = opt;

    btn.onclick = () => {
      startMusic();        // 🎵 pehle click pe music start
      checkAnswer(opt);
    };

    optionsDiv.appendChild(btn);
  });
}

function checkAnswer(selected) {
  const correct = quiz[current].answer;
  const feedback = document.getElementById("feedback");

  if (selected === correct) {
    feedback.innerHTML = "✅ Correct Answer!";
    feedback.style.color = "green";
    score++;
  } else {
    feedback.innerHTML = `❌ Wrong Answer! <br> ✔ Correct Answer: <b>${correct}</b>`;
    feedback.style.color = "red";
  }

  const buttons = document.querySelectorAll(".option-btn");
  buttons.forEach(btn => btn.disabled = true);
}

function nextQuestion() {
  current++;
  if (current < quiz.length) {
    loadQuestion();
  } else {
    document.querySelector(".card-body").innerHTML = `
      <h4>🎉 Quiz Completed</h4>
      <h5 class="mt-3">Score: ${score} / ${quiz.length}</h5>
      <button class="btn btn-success w-100 mt-3" onclick="location.reload()">
        Restart
      </button>
    `;
  }
}

loadQuestion();
